<template>
<div>
<button>Counter</button>
</div>
</template>

<script>
export default {
}
</script>

<style scoped>
button{
font-family: 'Avenir',
Helvetica, Arial, sans-serif;
text-align: center;
color: #bb0d38a8;
}
